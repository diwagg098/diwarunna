<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use RealRashid\SweetAlert\Facades\Alert;

class AuthController extends Controller
{
    public function index()
    {
        return view('login');
    }

    public function login(Request $request)
    {
        $username = $request->username;
        $password = $request->password;

        $content = DB::table('users')->where('username', $username)->first();

        if (!$username || !$password) {
            return redirect('/');
        }

        if (!$content) {
            Alert::error('', 'Username Anda salaha');
            return redirect('/');
        } else if ($password !== $content->password) {
            Alert::error('', 'Maaf password salah');
            return redirect('/');
        } else {

            Alert::success('Success', 'Halo ' . $content->nama);
            return redirect('/folder')->with('userdata', $request->session()->put([
                'nama' => $content->nama,
                'username' => $content->username,
                'email' => $content->email,
                'id' => $content->id,
                'is_login' => 1
            ]));
        }
    }

    public function logout(Request $request)
    {
        $request->session()->flush();
        Alert::success('', 'Anda berhasil logout');
        return redirect('/');
    }
}
