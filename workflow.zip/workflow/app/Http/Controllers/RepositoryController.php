<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\File;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use RealRashid\SweetAlert\Facades\Alert;

class RepositoryController extends Controller
{
    public function index(Request $request)
    {
        $role = $request->session()->has('is_login');
        if (!$role) {
            return redirect('/');
        }
        $content = DB::table('folder')->get();
        return view('welcome', compact('content'));
    }

    public function getDataFolder($id)
    {
        $content = DB::table('table_project')->where('id_folder', $id)->get();
        $folder = DB::table('folder')->where('id', $id)->first();
        return view('folder', [
            'folder' => $folder,
            'content' => $content
        ]);
    }

    public function upload(Request $request)
    {
        $file = $request->file('file');
        if (!$file) {
            alert()->error('Error', 'Belum ada file yang di upload');
            return back();
        } else {
            $ext = $file->getClientOriginalExtension();
            $fileName = $file->getClientOriginalName();
            $file->move(public_path() . '/file/', $fileName);
        }

        $data = [
            'tgl_upload' => date('Y-m-d H:i:s'),
            'nama_project' => 'CauseCode',
            'id_folder' => $request->id_folder,
            'upload_path' => $fileName,
            'ext' => $ext
        ];

        $save = DB::table('table_project')->insert($data);
        if ($save) {
            Alert::success('Success', 'File anda sudah diupload');
        } else {
            Alert::error('Gagal', 'Gagal upload file');
        }

        return redirect()->back();
    }

    public function addFolder(Request $request)
    {
        $folder = $request->nama_folder;
        if (!$folder) {
            Alert::warning('Warning', 'Nama Folder belum diisi');
            return back();
        }

        $data = [
            'nama_folder' => $folder
        ];

        DB::table('folder')->insert($data);
        return redirect('/folder');
    }

    public function deleteFolder($id)
    {
        $content = DB::table('folder')->where('id', $id)->first();
        if (DB::table('folder')->where('id', $id)->delete()) {
            DB::table('table_project')->where('id_folder', $content->id)->delete();
            Alert::success('Success', 'Folder ' . $content->nama_folder . ' berhasil dihapus');
        } else {
            Alert::error('', 'Oops terjadi kesalahan dalam menghapus item');
        }

        return redirect('/folder');
    }

    public function deleteFile($id)
    {
        $items = DB::table('table_project')->where('id', $id)->first();
        $delete = DB::table('table_project')->where('id', $id)->delete();
        $file_path = public_path() . '/file' . '/' . $items->upload_path;

        if ($delete) {
            if (File::exists($file_path)) {
                File::delete($file_path);
            }
            Alert::success('Success', $items->upload_path . ' berhasil dihapus');
        } else {
            Alert::warning('', 'Ooops terjadi kesalahan');
        }

        return redirect()->back();
    }
}
