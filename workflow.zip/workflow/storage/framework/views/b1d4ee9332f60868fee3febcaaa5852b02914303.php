<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php $__env->startSection('login'); ?>

<div class="bgform">
    <div class="form">
        <div class="head">
            <img src="<?php echo e(asset('/images/cg.png')); ?>" alt="">
            <h1>Login</h1>
        </div>



        <div class="login">

            <form action="<?php echo e(url('/login')); ?>" method="POST">
                <?php echo csrf_field(); ?>
            <div class="input">
                    <label for="uname"><b>Username</b></label>
                    <input type="text" placeholder="Enter Username" name="username"/>
                    <label for="uname"><b>Password</b></label>
                    <input type="password" name="password" placeholder="Enter Password" />
                    <button type="submit">SUBMIT</button>
                </div>
            </form>
        </div>
    </div>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\xampp\htdocs\workflow\resources\views/login.blade.php ENDPATH**/ ?>