<header>
    <nav>
        <img src="<?php echo e(asset('images/cg.png')); ?>" alt="">
    </nav>
    <div class="nav">
        <li><a href="">Chat</a></li>
        <li><a href="">About</a></li>
        <li><a href="">Drive</a></li>
        <li><a href="<?php echo e(url('/logout')); ?>">LOGOUT</a></li>
    </div>
</header>


<?php /**PATH C:\xampp\htdocs\workflow\resources\views/layout/nav.blade.php ENDPATH**/ ?>