<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('folder'); ?>



<button><a href="/folder"> <i class="fas fa-arrow-left fa-2x"></i></button></a> 
<form action="<?php echo e(url('/folder')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="tambah">
        <input type="hidden" name="id_user" value="<?php echo e(session('id')); ?>">
        <input type="hidden" name="id_folder" value="<?php echo e($folder->id); ?>">
        <input type="file" name="file" id="file" class="inputfile" style=""/>
        <button type="submit">Simpan</button>
    </div>
</form>



<div class="home">
    <div class="home1">
        <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="file">
            <a href="<?php echo e(asset('file/' . $row->upload_path)); ?>">                
                <?php if($row->ext == 'pdf'): ?>
                <i class="far fa-file-pdf fa-5x"></i>
                <?php elseif($row->ext == 'PDF'): ?>
                <i class="far fa-file-pdf fa-5x"></i>
                <?php elseif($row->ext == 'docx'): ?>
                <i class="far fa-file-word fa-5x"></i>
                <?php elseif($row->ext == 'xlsx'): ?>
                <i class="far fa-file-excel fa-5x"></i>
                <?php else: ?>
                <img src="<?php echo e(asset('file/' . $row->upload_path)); ?>" alt="" height="80">
                <?php endif; ?>
            <form action="<?php echo e(url('file/' . $row->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field("delete"); ?>
                <p><?php echo e($row->upload_path); ?></p></a>
                <button class="" id="dlt" type="submit"><i class="fas fa-trash-alt"></i></button>
            </form>
        </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php /**PATH C:\xampp\htdocs\workflow\resources\views/folder.blade.php ENDPATH**/ ?>