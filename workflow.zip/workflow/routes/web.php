<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/folder', 'RepositoryController@index');

Route::get('/', 'AuthController@index');
Route::post('/login', 'AuthController@login');
Route::get('/logout', 'AuthController@logout');

Route::delete('/folder/{id}', 'RepositoryController@deleteFolder');
Route::delete('/file/{id}', 'RepositoryController@deleteFile');
Route::get('/folder/{id}', 'RepositoryController@getDataFolder');
Route::post('/folder', 'RepositoryController@upload');
Route::post('/addFolder', 'RepositoryController@addFolder');
