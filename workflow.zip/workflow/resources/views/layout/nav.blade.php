<header>
    <nav>
        <img src="{{asset('images/cg.png')}}" alt="">
    </nav>
    <div class="nav">
        <li><a href="">Chat</a></li>
        <li><a href="">About</a></li>
        <li><a href="">Drive</a></li>
        <li><a href="{{ url('/logout')}}">LOGOUT</a></li>
    </div>
</header>


