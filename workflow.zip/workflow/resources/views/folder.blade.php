@include('layout.app')
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
@include('layout.nav')


@section('folder')



<button><a href="/folder"> <i class="fas fa-arrow-left fa-2x"></i></button></a> 
<form action="{{ url('/folder')}}" method="POST" enctype="multipart/form-data">
    @csrf
    <div class="tambah">
        <input type="hidden" name="id_user" value="{{ session('id')}}">
        <input type="hidden" name="id_folder" value="{{ $folder->id}}">
        <input type="file" name="file" id="file" class="inputfile" style=""/>
        <button type="submit">Simpan</button>
    </div>
</form>



<div class="home">
    <div class="home1">
        @foreach ($content as $row)
            <div class="file">
            <a href="{{ asset('file/' . $row->upload_path)}}">                
                @if ($row->ext == 'pdf')
                <i class="far fa-file-pdf fa-5x"></i>
                @elseif ($row->ext == 'PDF')
                <i class="far fa-file-pdf fa-5x"></i>
                @elseif ($row->ext == 'docx')
                <i class="far fa-file-word fa-5x"></i>
                @elseif ($row->ext == 'xlsx')
                <i class="far fa-file-excel fa-5x"></i>
                @else
                <img src="{{ asset('file/' . $row->upload_path)}}" alt="" height="80">
                @endif
            <form action="{{ url('file/' . $row->id)}}" method="POST">
                @csrf
                @method("delete")
                <p>{{ $row->upload_path}}</p></a>
                <button class="" id="dlt" type="submit"><i class="fas fa-trash-alt"></i></button>
            </form>
        </div>
            @endforeach
        </div>
    </div>
</div>
@include('sweetalert::alert')



